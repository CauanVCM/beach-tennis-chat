import Image from "next/image"
import { Clock } from "lucide-react"
import { Button } from "@/components/ui/button"

interface CourtCardProps {
  image: string
  title: string
  duration: string
  price: number
}

export default function CourtCard({ image, title, duration, price }: CourtCardProps) {
  return (
    <div className="flex border rounded-lg mb-4 overflow-hidden hover:shadow-md transition-shadow">
      <div className="w-[150px] h-[100px] relative flex-shrink-0">
        <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <div className="flex-1 p-4 flex flex-col justify-between">
        <div>
          <h3 className="font-medium text-lg">{title}</h3>
          <div className="flex items-center text-gray-500 mt-1">
            <Clock className="h-4 w-4 mr-1" />
            <span className="text-sm">{duration}</span>
          </div>
        </div>
        <div className="text-lg font-semibold">R$ {price.toFixed(2).replace(".", ",")}</div>
      </div>
      <div className="flex items-center pr-4">
        <Button variant="ghost" size="icon">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-6 w-6"
          >
            <polyline points="9 18 15 12 9 6"></polyline>
          </svg>
        </Button>
      </div>
    </div>
  )
}
