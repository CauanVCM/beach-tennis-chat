"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function SiteHeader() {
  const [activeTab, setActiveTab] = useState("Detalhes")

  const tabs = ["Detalhes", "Quadras", "Professores", "Assinaturas", "Avaliações", "Meu perfil"]

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Image
              src="/placeholder.svg?height=40&width=40"
              alt="Beach Tennis Logo"
              width={40}
              height={40}
              className="rounded-md"
            />
            <h1 className="text-lg font-semibold">Beach Tennis Premium</h1>
          </div>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="flex flex-col gap-4 mt-8">
                {tabs.map((tab) => (
                  <Link
                    key={tab}
                    href="#"
                    className={`text-lg ${activeTab === tab ? "font-medium text-orange-600" : "text-gray-600"}`}
                    onClick={() => setActiveTab(tab)}
                  >
                    {tab}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>

        <nav className="hidden md:flex mt-4 border-b">
          {tabs.map((tab) => (
            <Link
              key={tab}
              href="#"
              className={`px-4 py-2 text-sm ${
                activeTab === tab ? "border-b-2 border-orange-600 text-orange-600 font-medium" : "text-gray-600"
              }`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  )
}
