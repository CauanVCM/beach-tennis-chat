import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import CourtCard from "@/components/court-card"
import SiteHeader from "@/components/site-header"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <SiteHeader />

      <main className="container mx-auto px-4 py-6">
        <div className="flex flex-col items-center space-y-6 max-w-3xl mx-auto">
          <div className="w-full flex items-center gap-2">
            <Input type="text" placeholder="Procurar quadra" className="flex-1" />
            <Button variant="outline" size="icon">
              <Search className="h-4 w-4" />
              <span className="sr-only">Buscar</span>
            </Button>
          </div>

          <div className="w-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium flex items-center gap-2">
                <span className="inline-flex items-center justify-center rounded-full bg-orange-100 text-orange-800 w-6 h-6 text-sm">
                  1
                </span>
                Quadras Premium
              </h2>
              <Button variant="ghost" size="sm" className="text-sm">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </Button>
            </div>

            <CourtCard
              image="/placeholder.svg?height=100&width=150"
              title="Quadra Premium Areia Fina"
              duration="01:00 h"
              price={120.0}
            />

            <CourtCard
              image="/placeholder.svg?height=100&width=150"
              title="Quadra Premium Cobertura"
              duration="01:00 h"
              price={150.0}
            />
          </div>

          <div className="w-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium flex items-center gap-2">
                <span className="inline-flex items-center justify-center rounded-full bg-orange-100 text-orange-800 w-6 h-6 text-sm">
                  2
                </span>
                Quadras Padrão
              </h2>
              <Button variant="ghost" size="sm" className="text-sm">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </Button>
            </div>

            <CourtCard
              image="/placeholder.svg?height=100&width=150"
              title="Quadra Padrão Diurna"
              duration="30min"
              price={60.0}
            />

            <CourtCard
              image="/placeholder.svg?height=100&width=150"
              title="Quadra Padrão Noturna"
              duration="30min"
              price={75.0}
            />
          </div>

          <div className="w-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium flex items-center gap-2">
                <span className="inline-flex items-center justify-center rounded-full bg-orange-100 text-orange-800 w-6 h-6 text-sm">
                  3
                </span>
                Pacotes Especiais
              </h2>
              <Button variant="ghost" size="sm" className="text-sm">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
              </Button>
            </div>

            <CourtCard
              image="/placeholder.svg?height=100&width=150"
              title="Pacote Mensal (8 horas)"
              duration="02:00 h/semana"
              price={450.0}
            />
          </div>

          <Button className="w-full bg-orange-600 hover:bg-orange-700 text-white py-4">Agendar agora</Button>
        </div>
      </main>
    </div>
  )
}
